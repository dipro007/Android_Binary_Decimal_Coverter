package com.example.binarydecimalcoverter;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void add (View v){
        LinearLayout l1 =(LinearLayout)findViewById(R.id.Layout);
        TextView result = (TextView)findViewById(R.id.result);
        EditText input = (EditText)findViewById(R.id.EditText);
        String valueS = String.valueOf(input.getText());
        int valueI = Integer.parseInt(valueS);


        RadioButton b = (RadioButton)findViewById(R.id.b);
        RadioButton d = (RadioButton)findViewById(R.id.d);

        if(b.isChecked()){

            l1.setBackgroundColor(Color.RED);
            result.setText(b2d(valueI)+"");
            d.setChecked(true);
        }
        else{
            l1.setBackgroundColor(Color.DKGRAY);
            result.setText(d2b(valueS)+"");
            b.setChecked(true);
        }


    }

    private String d2b(String valueS){
        int dec =Integer.parseInt(valueS,2);
        return String.valueOf(dec);
    }
    private  String b2d(int valueI){
        String bin = Integer.toBinaryString(valueI);
        return bin;
    }

}


